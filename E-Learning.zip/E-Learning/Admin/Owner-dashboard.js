document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('.sidebar li');
    const tabContents = document.querySelectorAll('.tab-content');

    // Default configuration for fetching data
    const endpoints = {
        'pending': 'Backend/Owner/GetTeachers.php?status=pending',
        'approved': 'Backend/Owner/GetTeachers.php?status=approved',
        'stopped': 'Backend/Owner/GetTeachers.php?status=stopped'
    };

    // Initialize: Fetch pending teachers
    fetchTeachers('pending');

    // Tab Switching Logic
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            tab.classList.add('active');

            // Hide all contents
            tabContents.forEach(content => content.style.display = 'none');

            // Show target content
            const targetId = tab.getAttribute('data-tab');
            document.getElementById(targetId).style.display = 'block';

            // Fetch data for the selected tab
            fetchTeachers(targetId);
        });
    });

    function fetchTeachers(status) {
        const url = endpoints[status];
        const containerId = status; // ID of the tab content div
        const tbody = document.querySelector(`#${containerId} tbody`);

        // Clear existing rows (simulating refresh)
        tbody.innerHTML = '<tr><td colspan="5">Loading...</td></tr>';

        fetch(url)
            .then(response => response.json())
            .then(data => {
                tbody.innerHTML = ''; // Clear loading message

                if (data.success && data.data.length > 0) {
                    data.data.forEach(teacher => {
                        const tr = document.createElement('tr');

                        let actions = '';
                        if (status === 'pending') {
                            actions = `
                                <button class="approve-btn" onclick="updateStatus(${teacher.id}, 'approved')">Approve</button>
                                <button class="reject-btn" onclick="updateStatus(${teacher.id}, 'rejected')">Reject</button>
                            `;
                        } else if (status === 'approved') {
                            actions = `
                                <button class="stop-btn" onclick="updateStatus(${teacher.id}, 'stopped')">Stop</button>
                            `;
                        } else if (status === 'stopped') {
                            // Maybe allow re-approve? For now leave empty as per original HTML which only had view
                            actions = `<button class="approve-btn" onclick="updateStatus(${teacher.id}, 'approved')">Re-Approve</button>`;
                        }

                        tr.innerHTML = `
                            <td>${teacher.full_name}</td>
                            <td>${teacher.email}</td>
                            <td>${teacher.phone}</td>
                            <td>${teacher.speciality}</td>
                            <td>${actions}</td>
                        `;
                        tbody.appendChild(tr);
                    });
                } else {
                    tbody.innerHTML = '<tr><td colspan="5">No teachers found.</td></tr>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                tbody.innerHTML = '<tr><td colspan="5">Error loading data.</td></tr>';
            });
    }

    // Function to handle status updates (Global scope helper)
    window.updateStatus = function (teacherId, newStatus) {
        if (!confirm(`Are you sure you want to change status to ${newStatus}?`)) return;

        const formData = new FormData();
        formData.append('teacher_id', teacherId);
        formData.append('status', newStatus);

        fetch('Backend/Owner/UpdateStatus.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Refresh the current active tab
                    const activeTab = document.querySelector('.sidebar li.active').getAttribute('data-tab');
                    fetchTeachers(activeTab);
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred.');
            });
    }
});
