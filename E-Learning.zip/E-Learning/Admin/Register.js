document.addEventListener('DOMContentLoaded', () => {
    const studentRegisterForm = document.getElementById('studentRegisterForm');
    const teacherRegisterForm = document.getElementById('teacherRegisterForm');

    if (studentRegisterForm) {
        studentRegisterForm.addEventListener('submit', (e) => handleRegister(e, 'student'));
    }

    if (teacherRegisterForm) {
        teacherRegisterForm.addEventListener('submit', (e) => handleRegister(e, 'teacher'));
    }

    function handleRegister(event, role) {
        event.preventDefault();

        let name, email, phone, password, confirmPassword, speciality;

        if (role === 'student') {
            name = document.getElementById('regName').value;
            email = document.getElementById('regEmail').value;
            phone = document.getElementById('regPhone').value;
            password = document.getElementById('regPassword').value;
            confirmPassword = document.getElementById('regConfirmPassword').value;

            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }

            // API call to Backend/Student/Register.php
            const formData = new FormData();
            formData.append('full_name', name);
            formData.append('email', email);
            formData.append('phone', phone);
            formData.append('password', password);
            formData.append('confirm_password', confirmPassword);

            fetch('backend/Student/Register.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        window.location.href = 'Login.html';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });

        } else if (role === 'teacher') {
            name = document.getElementById('tRegName').value;
            email = document.getElementById('tRegEmail').value;
            phone = document.getElementById('tRegPhone').value;
            password = document.getElementById('tRegPassword').value;
            confirmPassword = document.getElementById('tRegConfirmPassword').value;
            speciality = document.getElementById('tRegSpeciality').value;

            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }

            // API call to Backend/Teacher/Register.php
            const formData = new FormData();
            formData.append('full_name', name);
            formData.append('email', email);
            formData.append('phone', phone);
            formData.append('password', password);
            formData.append('confirm_password', confirmPassword);
            formData.append('speciality', speciality);

            fetch('backend/Teacher/Register.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        window.location.href = 'Teacher-Login.html';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
        }
    }
});
