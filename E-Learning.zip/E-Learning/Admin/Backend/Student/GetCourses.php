<?php
header('Content-Type: application/json');
require_once "../config/db.php";

try {
    // Fetch courses with teacher names
    $stmt = $conn->prepare("
        SELECT courses.id, courses.title, courses.description, teachers.full_name as teacher_name 
        FROM courses 
        JOIN teachers ON courses.teacher_id = teachers.id 
        ORDER BY courses.created_at DESC
    ");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $courses]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
