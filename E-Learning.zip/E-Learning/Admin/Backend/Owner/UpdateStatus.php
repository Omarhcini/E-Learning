<?php
header('Content-Type: application/json');
require_once "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);

    // Support both JSON input and Form Data
    $teacherId = isset($_POST['teacher_id']) ? $_POST['teacher_id'] : (isset($data['teacher_id']) ? $data['teacher_id'] : null);
    $newStatus = isset($_POST['status']) ? $_POST['status'] : (isset($data['status']) ? $data['status'] : null);

    if (empty($teacherId) || empty($newStatus)) {
        echo json_encode(['success' => false, 'message' => 'Teacher ID and Status are required']);
        exit;
    }

    // Allowed statuses
    $allowedStatuses = ['pending', 'approved', 'rejected', 'stopped'];
    if (!in_array($newStatus, $allowedStatuses)) {
         echo json_encode(['success' => false, 'message' => 'Invalid status']);
         exit;
    }

    try {
        $stmt = $conn->prepare("UPDATE teachers SET status = :status WHERE id = :id");
        $stmt->execute([':status' => $newStatus, ':id' => $teacherId]);

        echo json_encode(['success' => true, 'message' => 'Status updated successfully']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
