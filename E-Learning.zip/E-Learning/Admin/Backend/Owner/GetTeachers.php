<?php
header('Content-Type: application/json');
require_once "../config/db.php";

$status = isset($_GET['status']) ? $_GET['status'] : 'pending';

try {
    $stmt = $conn->prepare("SELECT id, full_name, email, phone, speciality FROM teachers WHERE status = :status ORDER BY created_at DESC");
    $stmt->execute([':status' => $status]);
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $teachers]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
