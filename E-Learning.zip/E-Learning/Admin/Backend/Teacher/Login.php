<?php
header('Content-Type: application/json');
require_once "../config/db.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email    = isset($_POST["email"]) ? trim($_POST["email"]) : '';
    $password = isset($_POST["password"]) ? $_POST["password"] : '';

    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit;
    }

    try {
        $stmt = $conn->prepare("SELECT id, full_name, password, status FROM teachers WHERE email = :email");
        $stmt->execute([':email' => $email]);
        
        if ($stmt->rowCount() > 0) {
            $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (password_verify($password, $teacher['password'])) {
                
                // Check if account is approved
                if ($teacher['status'] === 'approved') {
                    // Login Success
                    $_SESSION['teacher_id'] = $teacher['id'];
                    $_SESSION['teacher_name'] = $teacher['full_name'];
                    
                    echo json_encode(['success' => true, 'message' => 'Login successful']);
                } else {
                    // Account not approved
                    echo json_encode(['success' => false, 'message' => 'Your account is pending approval or has been stopped.']);
                }

            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid password']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'User not found']);
        }

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
