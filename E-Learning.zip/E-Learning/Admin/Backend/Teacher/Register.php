<?php
header('Content-Type: application/json');
require_once "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $fullName   = isset($_POST["full_name"]) ? trim($_POST["full_name"]) : '';
    $speciality = isset($_POST["speciality"]) ? trim($_POST["speciality"]) : '';
    $email      = isset($_POST["email"]) ? trim($_POST["email"]) : '';
    $phone      = isset($_POST["phone"]) ? trim($_POST["phone"]) : '';
    $password   = isset($_POST["password"]) ? $_POST["password"] : '';
    $confirm    = isset($_POST["confirm_password"]) ? $_POST["confirm_password"] : '';

    // Validation
    if (empty($fullName) || empty($speciality) || empty($email) || empty($phone) || empty($password) || empty($confirm)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }

    if ($password !== $confirm) {
        echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
        exit;
    }

    // Password Hash
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    try {
        // Check if email already exists
        $checkStmt = $conn->prepare("SELECT id FROM teachers WHERE email = :email");
        $checkStmt->execute([':email' => $email]);
        
        if ($checkStmt->rowCount() > 0) {
             echo json_encode(['success' => false, 'message' => 'Email already exists']);
             exit;
        }

        $stmt = $conn->prepare("
            INSERT INTO teachers (full_name, speciality, email, phone, password, status)
            VALUES (:full_name, :speciality, :email, :phone, :password, 'pending')
        ");

        $stmt->execute([
            ":full_name"   => $fullName,
            ":speciality" => $speciality,
            ":email"      => $email,
            ":phone"      => $phone,
            ":password"   => $hashedPassword
        ]);

        echo json_encode(['success' => true, 'message' => 'Registration successful. Waiting for admin approval.']);

    } catch (PDOException $e) {
         // Log the error specifically in a real app, for now just generic message to user and specific for debug
         // For security, don't show full SQL errors in production, but helpful for dev
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
