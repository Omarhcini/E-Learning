document.addEventListener('DOMContentLoaded', () => {
    fetchCourses();

    function fetchCourses() {
        const coursesSection = document.getElementById('dynamic-courses');

        if (!coursesSection) {
            console.error("Could not find 'dynamic-courses' container");
            return;
        }

        coursesSection.innerHTML = '<p>Loading courses...</p>';

        fetch('Backend/Student/GetCourses.php')
            .then(response => response.json())
            .then(data => {
                coursesSection.innerHTML = ''; // Clear loading

                if (data.success && data.data.length > 0) {
                    data.data.forEach(course => {
                        const card = document.createElement('div');
                        card.className = 'dashboard-card';
                        card.innerHTML = `
                            <h3>${course.title}</h3>
                            <p>${course.description || 'No description available.'}</p>
                            <p><small>Instructor: ${course.teacher_name}</small></p>
                            <br>
                            <a href="#" class="btn-primary">Start Learning</a>
                        `;
                        coursesSection.appendChild(card);
                    });
                } else {
                    coursesSection.innerHTML = '<p>No courses available at the moment.</p>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                coursesSection.innerHTML = '<p>Error loading courses.</p>';
            });
    }
});
