/************************************************
 * INDEX PAGE SCRIPT
 * Handles basic homepage interactions
 ************************************************/

/*
  Fake authentication state
  --------------------------------
  Later this will come from backend / session
*/
let isLoggedIn = false; // change to true to simulate logged-in user
let userRole = "student"; // "student" | "teacher"

/*
  DOM ELEMENTS
*/
const startLearningBtn = document.querySelector(".btn-primary");
const nav = document.querySelector(".nav");

/*
  Handle navbar based on user state
*/
function updateNavbar() {
    if (isLoggedIn) {
        // Remove Login/Register
        nav.innerHTML = `
            <a href="#">Home</a>
            <a href="Courses.html">Courses</a>
            <a href="Teachers.html">Teachers</a>
            ${
                userRole === "teacher"
                    ? `<a href="teacher-dashboard.html" class="btn-outline">Dashboard</a>`
                    : `<a href="student-dashboard.html" class="btn-outline">Dashboard</a>`
            }
            <a href="#" id="logoutBtn" class="btn-outline">Logout</a>
        `;

        // Logout handler
        document.getElementById("logoutBtn").addEventListener("click", () => {
            isLoggedIn = false;
            location.reload();
        });
    }
}

/*
  Start Learning button behavior
*/
startLearningBtn.addEventListener("click", (e) => {
    e.preventDefault();

    if (!isLoggedIn) {
        window.location.href = "Register.html";
    } else {
        window.location.href =
            userRole === "teacher"
                ? "teacher-dashboard.html"
                : "student-dashboard.html";
    }
});

/*
  Initialize page
*/
updateNavbar();
