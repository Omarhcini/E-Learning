document.addEventListener('DOMContentLoaded', () => {
    const studentForm = document.getElementById('studentLoginForm');
    const teacherForm = document.getElementById('teacherLoginForm');

    if (studentForm) {
        studentForm.addEventListener('submit', (e) => handleLogin(e, 'student'));
    }

    if (teacherForm) {
        teacherForm.addEventListener('submit', (e) => handleLogin(e, 'teacher'));
    }

    function handleLogin(event, role) {
        event.preventDefault();

        let email, password;

        if (role === 'student') {
            email = document.getElementById('email').value;
            password = document.getElementById('password').value;

            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);

            fetch('backend/Student/Login.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = 'Student-dashboard.html';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
        } else if (role === 'teacher') {
            email = document.getElementById('teacherEmail').value;
            password = document.getElementById('teacherPassword').value;

            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);

            fetch('backend/Teacher/Login.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = 'Teacher-dashboard.html';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
            return; // Stop execution here for teacher

        }
    }
});
